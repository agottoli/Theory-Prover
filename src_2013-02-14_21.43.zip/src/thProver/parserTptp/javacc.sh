#!/bin/sh
#cd NetBeansProjects/RA/src/thProver/parserTptp/
../../../javacc-5.0/bin/javacc GrammarTptp.jj
