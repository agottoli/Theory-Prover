#!/bin/sh
#cd NetBeansProjects/RA/src/thProver/parser/
../../../javacc-5.0/bin/javacc Grammar.jj
